package com.caddie.voice.y1.dao;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface Y1Mapper {

}
