package com.caddie.voice.y1.controller;

import com.caddie.voice.y1.handler.ApiResponse;
import com.caddie.voice.y1.service.CourseViewService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@Api(tags = "y1 course view api service", description = "y1 course view api service")
@RequestMapping("/y1/courseView")
public class CourseViewController {
    private final CourseViewService courseViewService;

    public CourseViewController(CourseViewService courseViewService) {
        this.courseViewService = courseViewService;
    }

    @ApiOperation(value="course view home")
    @GetMapping("/home")
    public ApiResponse getCourseViewHome() {
        return courseViewService.getCourseViewHome();
    }
}
