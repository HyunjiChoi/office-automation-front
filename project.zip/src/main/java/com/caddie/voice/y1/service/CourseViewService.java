package com.caddie.voice.y1.service;

import com.caddie.voice.y1.handler.ApiResponse;
import com.caddie.voice.y1.handler.ApiResponseMap;
import org.springframework.stereotype.Service;

@Service
public class CourseViewService {

    public ApiResponse getCourseViewHome() {
        ApiResponseMap result = new ApiResponseMap();

        result.setResponseData("hole","H10");
        result.setResponseData("par","P4");

        result.setResponseData("backGreenDistance","403");
        result.setResponseData("pinDistance","386");
        result.setResponseData("frontGreenDistance","375");

        result.setResponseData("score","10");
        result.setResponseData("isAPL","1");
        result.setResponseData("location","??");

        return result;
    }
}
